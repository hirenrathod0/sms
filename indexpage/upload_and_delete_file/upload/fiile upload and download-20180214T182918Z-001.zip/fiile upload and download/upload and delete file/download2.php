<?php

	$db=new PDO("mysql:host=localhost;dbname=file","root","");
?>